'''
Q1. Faça um algoritmo que lê dois números, e verifica se os dois números são iguais. Se forem iguais, escrever "São iguais", se não, escrever "Não são iguais".
'''

numero1 = int(input("digite o 1º número: "));
print (numero1)
numero2 = int(input("digite o 2º número: "));

if(numero1 == numero2):
    print("são iguais!")
else:
    print("não são iguais!")
'''Faça um algoritmo que lê dois números, e verifica se o primeiro número é igual ao segundo número. Se forem iguais, escrever "Números iguais". Se não, escrever "Números diferentes".
'''

numero1 = int(input("digite o 1º número: "));
numero2 = int(input("digite o 2º número: "));

if(numero1 == numero2):
    print("números iguais!")
else:
    print("numeros diferentes!")